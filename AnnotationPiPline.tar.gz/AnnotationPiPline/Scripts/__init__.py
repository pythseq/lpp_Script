#!/usr/bin/env python
#coding:utf-8
"""
  Author:  LPP --<Lpp1985@hotmail.com>
  Purpose: 
  Created: 2015/1/2
"""
import os,sys
sys.path.append(os.path.split(__file__)[0])
sys.path.append(os.path.split(__file__)[0]+'/../lib/')

from lpp import *


if __name__ == '__main__':
	